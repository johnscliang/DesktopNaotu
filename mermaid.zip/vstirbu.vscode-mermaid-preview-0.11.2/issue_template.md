### Expected behaviour

```mermaid
Include the mermaid diagram
```

### Actual behaviour

Include:
   * Screenshot
   * Preview mode: Mermaid|Markdown
   * Theme used: light|dark
