<p>
  <h1 align="center">mindmap for VSCode</h1>
</p>

![mindmap](https://img.souche.com/f2e/1eadd508ee3488cb815b44c723c7154a.gif)

## 功能
- 在 vscode 中直接打开脑图文件（.km），并编辑、保存、导出。
- 在 vscode 中，打开 xmind 文件时，自动转换为 km 文件，并可编辑、保存。
- 支持导出为图片功能

## 下载

  在 vscode 插件市场中搜索 `mindmap` 并进行下载

## 使用

  插件加载成功之后，打开任何一个 .km 文件或者 .xmind 文件，插件就会自动开启一个对应文件的 webview 进行脑图的展示，用户可以在上面进行脑图的编辑、保存、导出。
  
## 使用场景

- 在 vscode 中维护测试用例
- 在 vscode 中维护文档和设计方案（脑图）

## 快捷键

| Key                              | Command                                                |
| -------------------------------- | ------------------------------------------------------ |
| cmd + m(mac) / ctrl + m(windows) | 开启文件的 webview                                     |
| cmd + s(mac) / ctrl + s(windows) | 保存脑图文件                                           |
| cmd + y(mac) / ctrl + y(windows) | 快速添加测试用例、前置条件、操作步骤、预期结果的子节点 |

## 常见问题

  - **km文件未能正确解析，展示在页面上的只是一个初始文件**
    
    可以尝试关闭当前文件及对应的脑图编辑器，重新打开文件

  - **mindmap插件安装无效**

    先检查vscode版本是否在1.29.0或以上，如果不是，请先升级到1.29.0或以上版本


[大搜车无线架构团队](https://blog.souche.com/tag/frontend/) 出品