angular
  .module('kityminderDemo', ['kityminderEditor'])
  .config(function(configProvider) {
    configProvider.set('imageUpload', '../server/imageUpload.php');
  })
  .controller('MainController', function($scope) {
    $scope.initEditor = function(editor, minder) {
      window.editor = editor;
      window.minder = minder;
      window.priorityCountMap = { '1': 0 };
      window.progressCountMap = { '1': 0, '9': 0 };
      window.usecaseCountMap = { '2': 0 };
      minder.execCommand('template', 'right');
      minder.execCommand('theme', 'fresh-blue-compat');

      window.addEventListener(
        'click',
        function(e) {
          var targetClassName = Array.from(e.target.classList).join(' ');
          if (
            targetClassName === 'km-priority-item tool-group-item ng-scope' ||
            targetClassName.indexOf('priority-') > -1 ||
            targetClassName ===
              'km-usecase-item km-priority-item tool-group-item' ||
            targetClassName.indexOf('usecase-btn') > -1 ||
            targetClassName === 'km-progress-item tool-group-item' ||
            targetClassName.indexOf('progress-') > -1
          ) {
            updatePriorityCount(window.minder.exportJson());
          }
        },
        false
      );

      window.addEventListener('message', event => {
        window.message = event.data;

        try {
          switch (window.message.command) {
            case 'import':
              var importData = JSON.parse(window.message.importData);
              window.minder.importJson(importData);
              updatePriorityCount(importData);
              window.minder.execCommand('template', 'right');
              window.minder.execCommand('theme', 'fresh-blue-compat');
              break;

            case 'init':
              var tabPane = document.querySelector('.tab-content .tab-pane');
              var progressBar = tabPane.querySelector('.km-progress');
              var excuteBar = tabPane.querySelector('.km-excute');
              var progressIcon1 = progressBar.querySelector(
                '.km-progress-item-1'
              );
              var progressIcon4 = progressBar.querySelector(
                '.km-progress-item-4'
              );
              var progressIcon5 = progressBar.querySelector(
                '.km-progress-item-5'
              );
              var progressIcon9 = progressBar.querySelector(
                '.km-progress-item-9'
              );
              var fileType = event.data.fileType;

              if (fileType === 'kme') {
                excuteBar.style.display = 'none';
              } else {
                progressBar.style.width = '95px';
                progressIcon1.style.display = 'none';
                progressIcon4.style.display = 'none';
                progressIcon5.style.display = 'none';
                progressIcon9.style.display = 'none';
              }
              break;

            case 'close':
              clearInterval(window.interval);
              break;
          }
        } catch (ex) {
          console.error(ex);
        }

        startAutoSaveTask();
      });

      document.addEventListener('keydown', function(e) {
        var keyCode = e.keyCode || e.which || e.charCode;
        var ctrlKey = e.ctrlKey || e.metaKey;
        if (ctrlKey && keyCode === 83) {
          var btnSave = document.querySelector('.btn-save');
          btnSave.click();
        }
        if (ctrlKey && keyCode === 89) {
          window.minder.execCommand('AppendChildNode', '分支主题');
          window.minder.execCommand('usecase', 2);
          window.minder.execCommand('AppendChildNode', '分支主题');
          window.minder.execCommand('usecase', 1);
          window.minder.execCommand('AppendSiblingNode', '分支主题');
          window.minder.execCommand('usecase', 4);
          window.minder.execCommand('AppendSiblingNode', '分支主题');
          window.minder.execCommand('usecase', 3);
        }
      });

      window.vscode.postMessage({
        command: 'loaded',
      });
    };
  });

function startAutoSaveTask() {
  window.interval = setInterval(function() {
    window.vscode.postMessage({
      command: 'save',
      exportData: JSON.stringify(window.minder.exportJson(), null, 4),
      isSilent: true,
    });
  }, 10000);
}

function updatePriorityCount(data) {
  var $bar = document.getElementById('J_PriorityStatusBar');
  try {
    window.priorityCountMap = { '1': 0 };
    window.progressCountMap = { '1': 0, '9': 0 };
    window.usecaseCountMap = { '2': 0 };
    processExportData(data);
    $bar.innerHTML = generateStatusBarText();
  } catch (ex) {
    console.error(ex);
  }
}

function processExportData(exportData) {
  var root = exportData.root;
  var walkTopic = function(topic) {
    var priority = topic.data.priority;
    var usecase = topic.data.usecase;
    var progress = topic.data.progress;

    if (priority === 1) {
      var size = window.priorityCountMap[priority.toString()];
      window.priorityCountMap['1'] = size + 1;
    }

    if (usecase === 2) {
      var size = window.usecaseCountMap[usecase.toString()];
      window.usecaseCountMap['2'] = size + 1;
    }

    if (progress === 1 || progress === 9) {
      var size = window.progressCountMap[progress.toString()];
      window.progressCountMap[progress.toString()] = size + 1;
    }

    if (topic.children && topic.children.length) {
      topic.children.forEach(function(child) {
        walkTopic(child);
      });
    }
  };

  walkTopic(root);
}

function generateStatusBarText() {
  var text = '';
  text += '测试用例数: ' + window.usecaseCountMap['2'];
  text += '   等级1: ' + window.priorityCountMap['1'];
  text += '   成功数: ' + window.progressCountMap['9'];
  text += '   失败数: ' + window.progressCountMap['1'];

  return text;
}

function hideViewSourcePanel() {
  var $viewSourcePanel = document.querySelector('#J_ViewSourcePanel');
  $viewSourcePanel.style.display = 'none';
}
